#
# Copyright="� Microsoft Corporation. All rights reserved."
#

configuration ConfigureSharePointServer
{

    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SharePointSetupUserAccountcreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SharePointFarmAccountcreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SharePointFarmPassphrasecreds,

        [parameter(Mandatory)]
        [String]$DatabaseName,

        [parameter(Mandatory)]
        [String]$AdministrationContentDatabaseName,

        [parameter(Mandatory)]
        [String]$DatabaseServer,

        [parameter(Mandatory)]
        [String]$Configuration,

        [Int]$RetryCount=30,
        [Int]$RetryIntervalSec=60
    )

    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential ]$FarmCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SharePointFarmAccountcreds.UserName)", $SharePointFarmAccountcreds.Password)
    [System.Management.Automation.PSCredential ]$SPsetupCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SharePointSetupUserAccountcreds.UserName)", $SharePointSetupUserAccountcreds.Password)


    Import-DscResource -ModuleName SharePointDSC

    Node localhost
    {
      
        SPCreateFarm ConfigureSharePointServer
        {
            DatabaseServer            = $DatabaseServer
            FarmConfigDatabaseName    = "SP_Config"
            AdminContentDatabaseName  = "SP_AdminContent"
            Passphrase                = $SharePointFarmPassphrasecreds
            FarmAccount               = $SharePointFarmAccountcreds
            PsDscRunAsCredential      = $SPsetupCreds
        }

      #  cConfigureSharepoint ConfigureSharepointServer
      #  {
      #      DomainName=$DomainName
      #      DomainAdministratorCredential=$DomainCreds
      #      DatabaseName=$DatabaseName
      #      AdministrationContentDatabaseName=$AdministrationContentDatabaseName
      #      DatabaseServer=$DatabaseServer
      #      SetupUserAccountCredential=$SPsetupCreds
      #     FarmAccountCredential=$SharePointFarmAccountcreds
      #      FarmPassphrase=$SharePointFarmPassphrasecreds
      #      Configuration=$Configuration
      #      DependsOn = "[xADUser]CreateFarmAccount","[xADUser]CreateSetupAccount", "[Group]AddSetupUserAccountToLocalAdminsGroup"
      #  }


    }
}