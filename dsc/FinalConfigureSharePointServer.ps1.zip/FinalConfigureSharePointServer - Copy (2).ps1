﻿Configuration SP2016Farm 
{
    param(
        [Parameter(Mandatory = $true)]
        [PSCredential]
        $SharePointFarmAccountcreds,

        [Parameter(Mandatory = $true)]
        [PSCredential]
        $SharePointSetupUserAccountcreds,

        [parameter(Mandatory)]
        [String]$DatabaseServer,

        [parameter(Mandatory)]
        [String]$DatabaseName,

        [parameter(Mandatory)]
        [String]$AdministrationContentDatabaseName,

        [Parameter(Mandatory = $true)]
        [PSCredential]
        $SharePointFarmPassphrasecreds
    )
    Import-DscResource -ModuleName SharePointDsc

    node localhost {
        SPCreateFarm CreateFarm
        {
            DatabaseServer            = $DatabaseServer
            FarmConfigDatabaseName    = $DatabaseName
            AdminContentDatabaseName  = $AdministrationContentDatabaseName
            Passphrase                = $SharePointFarmPassphrasecreds
            FarmAccount               = $SharePointFarmAccountcreds
            PsDscRunAsCredential      = $SharePointSetupUserAccountcreds
        }
    }
}