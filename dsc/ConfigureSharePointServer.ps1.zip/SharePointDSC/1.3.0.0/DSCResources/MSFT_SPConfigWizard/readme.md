**Description**

This resource is used to perform the upgrade step of installing SharePoint updates, like Cumulative Updates, Service Packs and Language Packs.
The DatabaseUpgradeDays and DatabaseUpgradeTime parameters specify a window in which the update can be installed.
This module has to be used to complete the update installation step, performed by SPProductUpdate.
