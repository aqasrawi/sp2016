**Description**

This resource is used to configure quota templates in the farm. These settings will 
be used to make sure a certain quota template exists or not. When it exists, it will 
also make sure the settings are configured as specified.
